<template>
  <panel>
    <div slot="title">{{$t('m.AboutUs')}}</div>
    <!-- v-katex v-html="aboutus.content" -->
    <div class="content markdown-body">
      <h1>
        WHO WE ARE?
      </h1>
      <p>
        Tryhardcode là hệ thống luyện tập và đánh giá kỹ năng lập trình thông qua các bài tập thực hành, cuộc thi viết mã với chức năng tự động chấm điểm để người dùng nâng cao kỹ năng và tăng hiệu suất làm việc.
      </p>
      <h1>
        VALUES
      </h1>
      <p>
        Một số lượng lớn các thách thức thuật toán khuyến khích người dùng tạo giải pháp bằng nhiều ngôn ngữ khác nhau.
      </p>
      <p>
        Cộng đồng dành cho các nhà phát triển đến, giải quyết vấn đề cùng nhau và học hỏi lẫn nhau.
      </p>
      <p>
       Người bạn đồng hành đáng tin cậy để cung cấp các cuộc thi cho các tổ chức và hỗ trợ các cá nhân lưu trữ mục tiêu của họ
      </p>
    </div>
	<p></p>
    <div class="content markdown-body update_time"><strong>last update time: </strong>{{aboutus.last_update_time | localtime }}</div>
  </panel>
</template>

<script>
  import api from '@oj/api'
  import Pagination from '@oj/components/Pagination'

  export default {
    name: 'AboutUs',
    components: {
      Pagination
    },
    data () {
      return {
        aboutus: ''
      }
    },
    mounted () {
      api.getAboutUs().then(res => {
        if (res.data.data) {
          this.aboutus = res.data.data
        } else {
          this.onit = true
        }
      }).catch(() => {
      })
    }
  }
</script>

<style lang="less" scoped>
  .content {
    font-size: 16px;
    margin: 0 50px 40px 50px;
    > ul {
      list-style: disc;
      li {
        font-size: 16px;
        margin-top: 20px;
        &:first-child {
          margin-top: 0;
        }
        p {
          font-size: 14px;
          margin-top: 5px;
        }
      }
    }
  }
  
  .update_time{
    text-align:right;
  }
</style>